@echo off
cd /d "%~dp0"
py -3 aio_list_bridge.py
if errorlevel 1 python aio_list_bridge.py
pause
