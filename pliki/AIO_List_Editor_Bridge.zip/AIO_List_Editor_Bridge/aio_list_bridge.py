#!/usr/bin/env python3
"""AIO List Bridge V1 - local-only FTP bridge; no cloud credentials.

Requires only Python 3 standard library. FTP is unencrypted and must be used
exclusively on a trusted local network. No passwords are persisted or logged.
"""
import base64
import binascii
import datetime as dt
import ftplib
import io
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from zipfile import ZipFile, ZIP_DEFLATED, BadZipFile

HOST = '127.0.0.1'
PORT = 8765
ORIGIN = 'https://aio-iptv-projekt.pages.dev'
MAX_REQUEST = 42 * 1024 * 1024
MAX_ZIP = 30 * 1024 * 1024
MAX_FILES = 800
MAX_UNCOMPRESSED = 65 * 1024 * 1024
FILE_PATTERN = re.compile(r'^(?:bouquets\.(?:tv|radio)|userbouquet\.[a-zA-Z0-9_.-]+\.(?:tv|radio)|lamedb5?|blacklist|whitelist)$')
TOKEN = secrets.token_urlsafe(28)
UPLOAD_LOCK = threading.Lock()
BRIDGE_ERRORS = (ValueError, RuntimeError, OSError) + ftplib.all_errors


def validate_address(address):
    try:
        ip = ipaddress.ip_address(address)
    except ValueError:
        raise ValueError('Wprowadź numeryczny adres IPv4 tunera.')
    if ip.version != 4 or not ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified:
        raise ValueError('Dozwolone są wyłącznie adresy lokalne IPv4 tunera.')
    octets = ip.packed
    if not (octets[0] == 10 or (octets[0] == 172 and 16 <= octets[1] <= 31) or (octets[0] == 192 and octets[1] == 168)):
        raise ValueError('Użyj prywatnego adresu tunera 10.x, 172.16–31.x albo 192.168.x.')
    return str(ip)


def extract_settings(zip_bytes):
    if len(zip_bytes) > MAX_ZIP:
        raise ValueError('ZIP przekracza 30 MB.')
    try:
        z = ZipFile(io.BytesIO(zip_bytes))
    except BadZipFile as exc:
        raise ValueError('Nieprawidłowe archiwum ZIP.') from exc
    result = {}
    candidates = z.infolist()
    if len(candidates) > MAX_FILES:
        raise ValueError('Archiwum zawiera zbyt wiele plików.')
    if sum(info.file_size for info in candidates) > MAX_UNCOMPRESSED:
        raise ValueError('Przekroczono bezpieczny limit danych po rozpakowaniu.')
    for item in candidates:
        name = item.filename.replace('\\', '/')
        if name.startswith('/') or '..' in name.split('/') or '\x00' in name:
            raise ValueError('Archiwum zawiera niebezpieczną ścieżkę.')
        if item.is_dir():
            continue
        filename = name.rsplit('/', 1)[-1]
        if not FILE_PATTERN.fullmatch(filename):
            continue
        if filename in result:
            raise ValueError('Duplikat pliku '+filename+' w archiwum.')
        if item.file_size > 9 * 1024 * 1024:
            raise ValueError('Plik '+filename+' jest zbyt duży.')
        result[filename] = z.read(item)
    z.close()
    if 'bouquets.tv' not in result or not any(k.startswith('userbouquet.') and k.endswith('.tv') for k in result):
        raise ValueError('ZIP nie zawiera pełnego zestawu bouquets.tv i bukietów TV Enigma2.')
    return result


def safe_backup_path(ip):
    base = Path.home() / 'AIO_List_Editor_Backups'
    base.mkdir(parents=True, exist_ok=True)
    now = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    return base / f'AIO_{ip.replace(".", "-")}_{now}_{secrets.token_hex(3)}_before_upload.zip'


def ftp_upload(ip, port, username, password, files):
    backup = safe_backup_path(ip)
    with ftplib.FTP() as ftp:
        ftp.connect(host=ip, port=port, timeout=22)
        ftp.login(user=username, passwd=password)
        ftp.set_pasv(True)
        ftp.cwd('/etc/enigma2')
        try:
            existing = {os.path.basename(x.rstrip('/')) for x in ftp.nlst()}
        except ftplib.all_errors as exc:
            raise RuntimeError('Nie można uzyskać listy plików /etc/enigma2, więc przerwano bez zmian.') from exc
        previous = {}
        # Download ALL originals before altering any file. This is mandatory.
        for name in files:
            if name not in existing:
                continue
            chunk = io.BytesIO()
            try:
                ftp.retrbinary('RETR '+name, chunk.write)
            except ftplib.all_errors as exc:
                raise RuntimeError('Nie można wykonać kopii '+name+', przerwano bez zmian.') from exc
            previous[name] = chunk.getvalue()
        with ZipFile(backup, 'w', ZIP_DEFLATED, compresslevel=6) as z:
            for name, content in previous.items():
                z.writestr(name, content)
            z.writestr('AIO_BACKUP_INFO.json', json.dumps({
                'ip': ip, 'time': dt.datetime.now(dt.timezone.utc).isoformat(),
                'original_files': sorted(previous),
                'new_files': sorted(set(files)-set(previous)),
                'instructions': 'Backup przed wysylka. Przywracaj przez FTP do /etc/enigma2.'
            }, indent=2))
        touched = []
        try:
            for name, content in files.items():
                # No deletions of existing unrelated bouquet files.
                touched.append(name)
                ftp.storbinary('STOR '+name, io.BytesIO(content), blocksize=32768)
                try:
                    remote_size = ftp.size(name)
                    if remote_size is not None and remote_size != len(content):
                        raise RuntimeError('Rozmiar wysłanego '+name+' nie zgadza się z ZIP.')
                except ftplib.error_perm as exc:
                    # Some embedded FTP servers don't support SIZE, not a fatal condition.
                    if not str(exc).startswith(('500','502','504')):
                        raise
        except Exception as exc:
            failures = []
            for name in reversed(touched):
                try:
                    if name in previous:
                        ftp.storbinary('STOR '+name, io.BytesIO(previous[name]))
                    else:
                        ftp.delete(name)
                except ftplib.all_errors:
                    failures.append(name)
            extra = (' Przywrócenie automatyczne nie powiodło się dla: '+', '.join(failures)+'.') if failures else ' Poprzedni stan przywrócono.'
            raise RuntimeError('Błąd podczas wysyłki: '+str(exc)+'.'+extra+' Kopia: '+str(backup)) from exc
    return {'uploaded':len(files),'backup':str(backup)}


class Handler(BaseHTTPRequestHandler):
    server_version = 'AIOListBridge/1.0'
    def log_message(self, fmt, *args):
        # Never print headers or request body (contains tuner password).
        print('AIO Bridge: '+fmt % args, flush=True)
    def _cors(self):
        origin = self.headers.get('Origin', '')
        if origin == ORIGIN:
            self.send_header('Access-Control-Allow-Origin', ORIGIN)
            self.send_header('Vary','Origin')
            self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers','Content-Type, X-AIO-Bridge-Token')
            self.send_header('Access-Control-Allow-Private-Network','true')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
    def _json(self, status, data):
        content = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self._cors()
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(content)))
        self.end_headers()
        self.wfile.write(content)
    def _auth(self):
        if self.headers.get('Origin') != ORIGIN:
            self._json(403, {'error':'Niedozwolona witryna. Otwórz oficjalną stronę AIO-IPTV.pl.'})
            return False
        if not secrets.compare_digest(self.headers.get('X-AIO-Bridge-Token',''), TOKEN):
            self._json(401, {'error':'Nieprawidłowy kod AIO List Bridge.'})
            return False
        return True
    def do_OPTIONS(self):
        if self.headers.get('Origin') != ORIGIN:
            self._json(403, {'error':'Niedozwolone źródło żądania.'})
            return
        self.send_response(204)
        self._cors()
        self.send_header('Content-Length','0')
        self.end_headers()
    def do_GET(self):
        if not self._auth():return
        if self.path != '/health':
            self._json(404, {'error':'Nieznana ścieżka.'})
        else:
            self._json(200, {'ok':True,'bridge':'AIO List Bridge V1','transport':'FTP (LAN only)'})
    def do_POST(self):
        if not self._auth():return
        if self.path != '/upload':
            self._json(404, {'error':'Nieznana ścieżka.'})
            return
        try:
            size = int(self.headers.get('Content-Length','0'))
            if size<10 or size>MAX_REQUEST:
                raise ValueError('Nieprawidłowy rozmiar żądania.')
            payload = json.loads(self.rfile.read(size).decode('utf-8'))
            ip = validate_address(str(payload.get('ip','')).strip())
            port = int(payload.get('port',21))
            if port<=0 or port>65535:raise ValueError('Nieprawidłowy port FTP.')
            username = str(payload.get('username',''))
            if username != 'root':raise ValueError('Dozwolony użytkownik: root.')
            password = str(payload.get('password',''))
            if len(password)>256:raise ValueError('Za długie hasło.')
            try:
                zip_bytes = base64.b64decode(str(payload.get('archive','')), validate=True)
            except (ValueError,binascii.Error):
                raise ValueError('Nieprawidłowe archiwum przesłane z przeglądarki.')
            files = extract_settings(zip_bytes)
            if not UPLOAD_LOCK.acquire(blocking=False):
                self._json(429, {'error':'Trwa już wysyłanie listy. Poczekaj na zakończenie.'})
                return
            try:
                result = ftp_upload(ip, port, username, password, files)
            finally:
                UPLOAD_LOCK.release()
            self._json(200, {'ok':True, **result})
        except BRIDGE_ERRORS as exc:
            self._json(400, {'error':str(exc)[:1000]})
        except Exception:
            self._json(500, {'error':'Nieoczekiwany błąd programu AIO List Bridge.'})


if __name__ == '__main__':
    print('AIO List Bridge V1 — lokalne połączenie tylko z 127.0.0.1')
    print('Witryna: '+ORIGIN)
    print('Kod mostu (wklej na stronie): '+TOKEN)
    print('Protokół: FTP bez szyfrowania. Tylko zaufana sieć lokalna!')
    print('Nie publikuj tego kodu. Ctrl+C kończy pracę programu.',flush=True)
    try:
        ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
    except KeyboardInterrupt:
        print('\nAIO List Bridge zatrzymany.')
