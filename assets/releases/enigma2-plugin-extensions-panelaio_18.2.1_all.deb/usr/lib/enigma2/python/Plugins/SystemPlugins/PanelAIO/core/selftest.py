# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

import json
import os
import re
import sys

try:
    from Plugins.SystemPlugins.PanelAIO.core.source_registry import TRUSTED_REMOTE_SCRIPTS
except Exception:
    try:
        from source_registry import TRUSTED_REMOTE_SCRIPTS
    except Exception:
        TRUSTED_REMOTE_SCRIPTS = set()

VERSION = '18.2.1'


def _read(path):
    with open(path, 'r') as handle:
        return handle.read()


def _require(root, rel, errors):
    path = os.path.join(root, rel)
    if not os.path.isfile(path) or os.path.getsize(path) <= 0:
        errors.append('missing: %s' % rel)


def run(root):
    errors = []
    try:
        version = _read(os.path.join(root, 'version.txt')).strip()
    except Exception as exc:
        version = ''
        errors.append('version.txt unreadable: %s' % exc)
    if version != VERSION:
        errors.append('unexpected version.txt: %s' % version)

    required = [
        'plugin.py', 'runtime.py', 'legacy_plugin.py',
        'data/catalog.py', 'core/list_health.py', 'core/feed_inventory.py', 'core/password.py', 'install_feed_package.sh', 'install_fury_package.sh',
        'core/logger.py', 'core/result.py', 'core/action_registry.py',
        'core/action_dispatcher.py', 'core/activity.py', 'core/source_registry.py',
        'core/plugin_state.py', 'core/selftest.py',
        'data/navigation.py', 'data/owned_projects.py', 'data/requested_installers.py', 'core/oscam_data.py',
        'ui/modern.py', 'ui/appearance.py', 'ui/media_list.py', 'core/skin_previews.py',
        'assets/previews/credits.txt', 'assets/previews/catalog.json', 'assets/previews/channel_samples.json',
        'core/media_catalog.py', 'ui/media_details.py', 'core/skin_feed.py',
        'assets/previews/picons/13e.png', 'assets/previews/picons/19e.png', 'assets/previews/picons/both.png', 'ui/screens/connect.py', 'installer.sh',
        'safe_ipk_install.sh', 'install_iptv_dream_safe.sh',
        'install_s4aupdater_safe.sh', 'install_picon_updater_safe.sh',
        'install_myupdater_safe.sh', 'aio_safe_common.sh',
        'install_github_package_safe.sh', 'install_phub_safe.sh',
        'core/third_party_package_validator.py',
    ]
    for rel in required:
        _require(root, rel, errors)

    try:
        json.loads(_read(os.path.join(root, 'custom_updates.json')))
    except Exception as exc:
        errors.append('custom_updates.json invalid: %s' % exc)

    try:
        runtime = _read(os.path.join(root, 'runtime.py'))
        urls = set(re.findall(r'["\']remote_script(?:_bash)?:([^"\'|]+)(?:\|[^"\']+)?["\']', runtime))
        missing = sorted(urls.difference(TRUSTED_REMOTE_SCRIPTS))
        if missing:
            errors.append('unregistered remote scripts: %s' % ', '.join(missing))
        for marker in (
            'CMD:AIO_SEARCH', 'CMD:AIO_SOURCE_HEALTH', 'CMD:AIO_FAVORITES',
            'CMD:AIO_RECENT', 'CMD:INSTALL_S4AUPDATER',
            'CMD:INSTALL_PICON_UPDATER', 'CMD:INSTALL_MYUPDATER',
            'CMD:INSTALL_JEDI_GITHUB', 'CMD:INSTALL_CHOCHO_GITHUB', 'CMD:INSTALL_PHUB',
        ):
            if marker not in runtime:
                errors.append('runtime action missing: %s' % marker)
        for method in ('install_s4aupdater_safe', 'install_picon_updater_safe', 'install_myupdater_safe'):
            if ('def %s(' % method) not in runtime:
                errors.append('runtime method missing: %s' % method)
        # Dedicated installers must not regress back to the generic direct action payload.
        if '"🔄 MyUpdater v5.1 - Instalator", "remote_script:' in runtime:
            errors.append('MyUpdater still uses generic remote_script action')
        if '"🖼️ Picon Updater - Instalator (Picony)", "remote_script:' in runtime:
            errors.append('PiconUpdater still uses generic remote_script action')
    except Exception as exc:
        errors.append('runtime audit failed: %s' % exc)

    try:
        shim = _read(os.path.join(root, 'legacy_plugin.py'))
        if 'PanelAIO.runtime import *' not in shim:
            errors.append('legacy compatibility shim does not point to runtime.py')
        if len(shim.splitlines()) > 40:
            errors.append('legacy_plugin.py unexpectedly contains runtime code')
    except Exception as exc:
        errors.append('legacy shim audit failed: %s' % exc)

    try:
        plugin = _read(os.path.join(root, 'plugin.py'))
        if '_maintenance_task()' in plugin:
            errors.append('obsolete startup maintenance call remains')
        if '_run_auto_ram_clean_task()' not in plugin:
            errors.append('startup maintenance implementation missing')
    except Exception as exc:
        errors.append('plugin.py audit failed: %s' % exc)

    installer_expectations = {
        'install_picon_updater_safe.sh': (
            'https://raw.githubusercontent.com/OliOli2013/PiconUpdater/main/installer.sh',
            'aio_secure_download "$URL" "$FILE"',
            'picon-updater',
        ),
        'install_myupdater_safe.sh': (
            'https://raw.githubusercontent.com/OliOli2013/MyUpdater-Plugin/main/installer.sh',
            'aio_secure_download "$URL" "$FILE"',
            'myupdater',
        ),
        'install_iptv_dream_safe.sh': (
            'https://raw.githubusercontent.com/OliOli2013/IPTV-Dream-Plugin/main/installer.sh',
            'aio_secure_download "$URL" "$FILE"',
            'iptv-dream',
        ),
        'install_s4aupdater_safe.sh': (
            'http://s4aupdater.one.pl/instalujs4aupdater.sh',
            'wget "$URL" -O "$FILE"',
            'transport=legacy-http',
        ),
    }
    for rel, markers in installer_expectations.items():
        try:
            text = _read(os.path.join(root, rel))
            for marker in markers:
                if marker not in text:
                    errors.append('%s marker missing: %s' % (rel, marker))
        except Exception as exc:
            errors.append('%s audit failed: %s' % (rel, exc))

    try:
        owned = _read(os.path.join(root, 'data/owned_projects.py'))
        navigation = _read(os.path.join(root, 'data/navigation.py'))
        if 'PROJECT_ACTIONS' not in navigation or "('projects', 'Moje projekty', 'My projects')" not in navigation:
            errors.append('owned projects tab not registered directly after channels')
        if "groups['projects'] = project_items(lang)" not in navigation:
            errors.append('owned projects are not populated')
        if 'item[1] not in PROJECT_ACTIONS' not in navigation:
            errors.append('duplicate owned project actions may remain in other tabs')
        for repo in ('IPTV-Dream-Plugin', 'MyUpdater-Plugin', 'PiconUpdater',
                     'SimpleIPTV_EPG', 'NeoRadio', 'PPChannelSync-Plugin',
                     'E2-Doctor-Plugin', 'AIOHD-NEXT-Skin', 'OpenCamView-Plugin'):
            if repo not in owned:
                errors.append('owned repository missing: %s' % repo)
    except Exception as exc:
        errors.append('owned projects audit failed: %s' % exc)

    return errors


def main(argv):
    root = argv[1] if len(argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    errors = run(root)
    if errors:
        for item in errors:
            print('ERROR|%s' % item)
        return 1
    print('OK|AIO Panel %s self-test' % VERSION)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
